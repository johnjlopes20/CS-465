const mongoose = require('./database');
const Trip = require('./tripModel');
const trips = require('./trips.json');

const populateTrips = async () => {
    try {
        await Trip.deleteMany(); // Clear existing data
        await Trip.insertMany(trips); // Insert mock data
        console.log('Database populated with sample trips');
        mongoose.connection.close(); // Close the connection after populating
    } catch (err) {
        console.error('Error populating database:', err);
    }
};

populateTrips();
