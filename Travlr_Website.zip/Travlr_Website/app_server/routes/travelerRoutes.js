const express = require('express');
const router = express.Router();
const travelerController = require('../controllers/travelerController');

// Route for the home page
router.get('/', travelerController.home);

module.exports = router;
