exports.homePage = (req, res) => {
  res.render('index', { title: 'Home - Travlr Getaways' });
};

exports.aboutPage = (req, res) => {
  res.render('about', { title: 'About Us - Travlr Getaways' });
};

exports.contactPage = (req, res) => {
  res.render('contact', { title: 'Contact Us - Travlr Getaways' });
};
