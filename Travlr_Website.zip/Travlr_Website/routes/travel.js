const express = require('express');
const router = express.Router();
const fs = require('fs');
const trips = JSON.parse(fs.readFileSync('./data/trips.json', 'utf8'));

router.get('/trips', (req, res) => {
    res.render('trips', { trips: trips });
});

module.exports = router;
