const express = require('express');
const router = express.Router();
const tripsData = require('../data/trips.json'); // Correct path to the JSON file

// Route to render trips page
router.get('/trips', (req, res) => {
    res.render('trips', { trips: tripsData }); // Render the trips view
});

module.exports = router;
