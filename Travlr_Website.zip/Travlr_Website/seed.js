const mongoose = require('mongoose');
const connectDB = require('./database'); // Ensure this file exists and is correct
const Trip = require('./Trip'); // Ensure this file exists and is correct

connectDB();

const seedTrips = async () => {
  await Trip.deleteMany({}); // Clear existing data
  const trips = [
    { name: 'Beach Getaway', price: 499, location: 'Hawaii', date: new Date('2024-12-15') },
    { name: 'Mountain Adventure', price: 349, location: 'Colorado', date: new Date('2024-10-01') },
  ];

  await Trip.insertMany(trips);
  console.log('Database seeded!');
  mongoose.connection.close();
};

seedTrips();
