const express = require('express');
const exphbs = require('express-handlebars');
const path = require('path');

const app = express();

// Set up handlebars view engine
app.engine('hbs', exphbs.engine({ extname: 'hbs', defaultLayout: 'main' }));
app.set('view engine', 'hbs');
app.set('views', path.join(__dirname, 'app_server/views'));

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Define routes here
app.get('/', (req, res) => {
    res.render('home', { title: 'Home - Travlr Getaways' });
});

app.listen(3000, () => {
    console.log('Server is running on port 3000');
});
