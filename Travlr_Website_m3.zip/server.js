const express = require('express');
const exphbs = require('hbs');
const path = require('path');
const travelRoutes = require('./routes/travel'); // Add this line

const app = express();
const port = 3000;

// Set the view engine to Handlebars
app.set('view engine', 'hbs');
// Set the views directory
app.set('views', path.join(__dirname, 'views'));

// Serve static files
app.use(express.static('public'));

// Use the travel routes
app.use('/', travelRoutes); // Add this line

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
